-- Generated Lua Manifest by DEV/g0d
-- Steam App 3656800 Manifest
-- Name: Train Sim World® 6
-- Total Depots: 139
-- Total DLCs: 128

-- MAIN APPLICATION
addappid(3656800) -- Train Sim World® 6
addtoken(3656800, "14036505725109272009")
-- MAIN APP DEPOTS
addappid(3656801, 1, "d415d0715c7c598555201be1db2343f83a6ae2c7d65834a31c40babae33efe45") -- Depot 3656801
setManifestid(3656801, "6102588967907291162", 6803331826)
addappid(3662580, 1, "6f02d62d3b6c384b914021f2ca95a95fa45e513113f8dedfde646b96fa34a9af") -- Depot 3662580
setManifestid(3662580, "5107719921825084743", 7025984536)
addappid(3663660, 1, "3cf6f4619b2c4fa2cb281ece46f91cf43d752a05e89340b9e4dbe66f8c4d00fd") -- Depot 3663660
setManifestid(3663660, "6135087579830959654", 9702602043)
addappid(3663670, 1, "9e084209730915b3a1ebc1b5554a13b74a53fcf37ead2da851355abdb4481bbc") -- Depot 3663670
setManifestid(3663670, "8849018171069037357", 11741650838)
addappid(3663680, 1, "acc7fc8d1c5837441c2973e01f23dc62d3d43ef88564b1e63adcfd57c3130338") -- Depot 3663680
setManifestid(3663680, "1903738116052166891", 6855697194)
addappid(3663690, 1, "e1d7e73e723931680048ccfcfc48269ea4115ee33f9499b41783ede684f5ce1c") -- Depot 3663690
setManifestid(3663690, "2784446826815972403", 145253315)
addappid(3663700, 1, "5a9c100f4aa7345b892607fb0b8701f24afc2a0a1cb3e75a845f2e3a1586c84d") -- Depot 3663700
setManifestid(3663700, "2662556475992590096", 208885341)
addappid(3663800, 1, "3d93c966a49d7bc799964b81d82ae9cf330829bf0911e2a4a00c7e4fed7bbe50") -- Depot 3663800
setManifestid(3663800, "1090441514618039884", 260231902)
-- DLCS WITH DEDICATED DEPOTS
-- Train Sim World 6 Great Western Express Route Add-On (AppID: 3656860)
addappid(3656860)
addappid(3656860, 1, "0b6ceac173d821e0442a8ac12ef889af41d2408448eac52ea0593de4a30bf8c9") -- Train Sim World 6 Great Western Express Route Add-On - Depot 3656860
setManifestid(3656860, "8581787728845002580", 4605518501)
-- Train Sim World 6 Rapid Transit Route Add-On (AppID: 3656870)
addappid(3656870)
addappid(3656870, 1, "f4e5216b8143878eb4dd779f604fb2d1499efea78cd87044c459962595cde206") -- Train Sim World 6 Rapid Transit Route Add-On - Depot 3656870
setManifestid(3656870, "4386643500615142937", 3862843241)
-- Train Sim World 6 West Somerset Railway Route Add-On (AppID: 3656880)
addappid(3656880)
addappid(3656880, 1, "9a07f47079b870549795d29977a7411384313bf710e491ac630d12c5955cd330") -- Train Sim World 6 West Somerset Railway Route Add-On - Depot 3656880
setManifestid(3656880, "7564411487202865859", 2376066849)
-- Train Sim World 6 Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On (AppID: 3656890)
addappid(3656890)
addappid(3656890, 1, "a3f0551af4d5fe197ec015ec80bf2159748d361b56b64a49bacac0019a02818e") -- Train Sim World 6 Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On - Depot 3656890
setManifestid(3656890, "8789102968239073082", 3699836674)
-- Train Sim World 6 Long Island Rail Road New York - Hicksville Route Add-On (AppID: 3656900)
addappid(3656900)
addappid(3656900, 1, "1e80fd3f7f51936279d2ca0e2ea7ffde519a555f3565087e31f747a013526a9f") -- Train Sim World 6 Long Island Rail Road New York - Hicksville Route Add-On - Depot 3656900
setManifestid(3656900, "7070173484525272879", 4505290370)
-- Train Sim World 6 Northern Trans-Pennine Manchester - Leeds Route Add-On (AppID: 3656910)
addappid(3656910)
addappid(3656910, 1, "8793807e6db829e9018a32c162ef72e95d601bbf8a5bb9d17f2c3fe3f53a35f9") -- Train Sim World 6 Northern Trans-Pennine Manchester - Leeds Route Add-On - Depot 3656910
setManifestid(3656910, "8359817671229274122", 4840124059)
-- Train Sim World 6 BR Class 33 Add-On (AppID: 3656920)
addappid(3656920)
addappid(3656920, 1, "b1c3ec6bb19a79f5270d1dc6f7f2f863f7ca4d0c316760af41e95bd45fbaf30e") -- Train Sim World 6 BR Class 33 Add-On - Depot 3656920
setManifestid(3656920, "8715331486071187289", 87143014)
-- Train Sim World 6 Main-Spessart Bahn Aschaffenburg - Gemunden Route Add-On (AppID: 3656930)
addappid(3656930)
addappid(3656930, 1, "c64d5dcd1c02bdba548e9053392b7c6be506163fe113accdf32db7f6a4826284") -- Train Sim World 6 Main-Spessart Bahn Aschaffenburg - Gemunden Route Add-On - Depot 3656930
setManifestid(3656930, "6933199110478978850", 3369049609)
-- Train Sim World 6 DB BR 182 Loco Add-On (AppID: 3656940)
addappid(3656940)
addappid(3656940, 1, "d015b3ab4b4a357d0d7dd6d665506d27754f57692d16f821d38f93a463f932cc") -- Train Sim World 6 DB BR 182 Loco Add-On - Depot 3656940
setManifestid(3656940, "4433376997061757583", 236110553)
-- Train Sim World 6 DB BR 155 Loco Add-On (AppID: 3656950)
addappid(3656950)
addappid(3656950, 1, "a57615875489c7c7996adad38ad4612d3e67e0cf4b69f5a560100cfcc3be29af") -- Train Sim World 6 DB BR 155 Loco Add-On - Depot 3656950
setManifestid(3656950, "4462574987134713632", 152450697)
-- Train Sim World 6 BR Class 52 Add-On (AppID: 3662270)
addappid(3662270)
addappid(3662270, 1, "db67a712cccd05521e8ac0162e57d5473d76627e0e57589ee139e284ab210677") -- Train Sim World 6 BR Class 52 Add-On - Depot 3662270
setManifestid(3662270, "7412811026218674508", 84308031)
-- Train Sim World 6 BR Heavy Freight Pack Loco Add-On (AppID: 3662280)
addappid(3662280)
addappid(3662280, 1, "809fc9a143e404dc384a276e17f7b39d3d3a77dc025fc781239499448803e824") -- Train Sim World 6 BR Heavy Freight Pack Loco Add-On - Depot 3662280
setManifestid(3662280, "3520977172117517097", 234010893)
-- Train Sim World 6 Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On (AppID: 3662290)
addappid(3662290)
addappid(3662290, 1, "efeff2fd05b2c9487c77939731baeadc5064aa0f4da5c609e23a88e151255092") -- Train Sim World 6 Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On - Depot 3662290
setManifestid(3662290, "4758041562273759181", 4241057423)
-- Train Sim World 6 Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On (AppID: 3662310)
addappid(3662310)
addappid(3662310, 1, "f798bffe0a7b5c73f327b75986d652d0b37588f3d4b86819217928bd5b3fe5ac") -- Train Sim World 6 Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On - Depot 3662310
setManifestid(3662310, "6157551414697875104", 4455656512)
-- Train Sim World 6 BR Class 31 Loco Add-On (AppID: 3662320)
addappid(3662320)
addappid(3662320, 1, "e70d3610ca48d6efe8551b3bfc058b9d87d3ce5074a5b3890d5f9074765940c2") -- Train Sim World 6 BR Class 31 Loco Add-On - Depot 3662320
setManifestid(3662320, "5650002217134188850", 135144912)
-- Train Sim World 6 East Coastway Brighton - Eastbourne  Seaford Route Add-On (AppID: 3662330)
addappid(3662330)
addappid(3662330, 1, "a45c2f9ac4e1a17719663e61abf37c45f24b3b36e56267f88b522ac3584d4e27") -- Train Sim World 6 East Coastway Brighton - Eastbourne  Seaford Route Add-On - Depot 3662330
setManifestid(3662330, "5916361261617598420", 3904480450)
-- Train Sim World 6 Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On (AppID: 3662350)
addappid(3662350)
addappid(3662350, 1, "298226727b368624a3f10b5e441e6985dd93e510b02536aa2644c853bfe480e2") -- Train Sim World 6 Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On - Depot 3662350
setManifestid(3662350, "3791370461537702790", 2512804413)
-- Train Sim World 6 Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On (AppID: 3662370)
addappid(3662370)
addappid(3662370, 1, "c67f14ac6c977013dd03746eb231f148f8e11093f73b5e800b0f637468415e4a") -- Train Sim World 6 Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On - Depot 3662370
setManifestid(3662370, "9145153042319768777", 2868642048)
-- Train Sim World 6 DB BR 204 Add-On (AppID: 3662380)
addappid(3662380)
addappid(3662380, 1, "d96a13ed8d455eaa55f756092a1e99c58966135238334d8f51f3b390b9da9182") -- Train Sim World 6 DB BR 204 Add-On - Depot 3662380
setManifestid(3662380, "5002234049054851166", 122244797)
-- Train Sim World 6 LIRR M3 EMU Add-On (AppID: 3662390)
addappid(3662390)
addappid(3662390, 1, "bafb14d8b0bce9f8e3a367f0b4640a1a0c0f5d8c829f0c154bf8b21a7068ba14") -- Train Sim World 6 LIRR M3 EMU Add-On - Depot 3662390
setManifestid(3662390, "4907309678936369902", 134097526)
-- Train Sim World 6 BR Class 20 Chopper Loco Add-On (AppID: 3662400)
addappid(3662400)
addappid(3662400, 1, "4965048fe197fb58af0f6a5b835f374f05fc65cbc88520cff19703df373ce32c") -- Train Sim World 6 BR Class 20 Chopper Loco Add-On - Depot 3662400
setManifestid(3662400, "5779066394241079170", 134141939)
-- Train Sim World 6 Isle Of Wight Ryde - Shanklin Route Add-On (AppID: 3662410)
addappid(3662410)
addappid(3662410, 1, "13f008aaba89f470a8f88a4b3c96324436425ea4e6542143293da88978ff10c7") -- Train Sim World 6 Isle Of Wight Ryde - Shanklin Route Add-On - Depot 3662410
setManifestid(3662410, "7253066674865792410", 2359273679)
-- Train Sim World 6 Hauptstrecke Munchen - Augsburg Route Add-On (AppID: 3662420)
addappid(3662420)
addappid(3662420, 1, "d56761a97f3107de307ba6c9f2638e9dcc7a1c2ac46e75aa27f97bc12f90a8f0") -- Train Sim World 6 Hauptstrecke Munchen - Augsburg Route Add-On - Depot 3662420
setManifestid(3662420, "5796417457550246470", 4497917253)
-- Train Sim World 6 DB BR 363 Loco Add-On (AppID: 3662430)
addappid(3662430)
addappid(3662430, 1, "4bfd5de35e75989c7a4e73a5c1e452c43c0906d85b222f1720a22d0aebb2c09f") -- Train Sim World 6 DB BR 363 Loco Add-On - Depot 3662430
setManifestid(3662430, "8615635114473439563", 179954288)
-- Train Sim World 6 Southern BR Class 313 EMU Add-On (AppID: 3662440)
addappid(3662440)
addappid(3662440, 1, "23166df15915e7e346d6986d702cd591692fa8bd65a26c9e0c187e89ec16540b") -- Train Sim World 6 Southern BR Class 313 EMU Add-On - Depot 3662440
setManifestid(3662440, "7863460541392876755", 157727227)
-- Train Sim World 6 CSX C40-8W Loco Add-On (AppID: 3662450)
addappid(3662450)
addappid(3662450, 1, "7c7228b295b137c73d9145da7c676ad382a885df7a88a532d8fe3c594438d745") -- Train Sim World 6 CSX C40-8W Loco Add-On - Depot 3662450
setManifestid(3662450, "5022087768462461946", 224685747)
-- Train Sim World 6 LGV Mediterranee Marseille - Avignon Route Add-On (AppID: 3662460)
addappid(3662460)
addappid(3662460, 1, "19dd3e5d5b99d1c2f96cc4a04878d129f84f0713cf3e804f42d867cfc0fff278") -- Train Sim World 6 LGV Mediterranee Marseille - Avignon Route Add-On - Depot 3662460
setManifestid(3662460, "9097792192615575139", 3972601720)
-- Train Sim World 6 Arosalinie Chur - Arosa Route Add-On (AppID: 3662490)
addappid(3662490)
addappid(3662490, 1, "9c11e149e97fbf5bdbfab2c39a550a0788d24908456695bd86340159bdabd920") -- Train Sim World 6 Arosalinie Chur - Arosa Route Add-On - Depot 3662490
setManifestid(3662490, "2826466509550751269", 3912660687)
-- Train Sim World 6 Cane Creek Thompson - Potash Route Add-On (AppID: 3662500)
addappid(3662500)
addappid(3662500, 1, "1f24056c771448c6f319013c2008636ef66947b2cc673bc4df081a80126337f9") -- Train Sim World 6 Cane Creek Thompson - Potash Route Add-On - Depot 3662500
setManifestid(3662500, "4384362869902890529", 3740236364)
-- Train Sim World 6 DB BR 187 Loco Add-On (AppID: 3662510)
addappid(3662510)
addappid(3662510, 1, "fd6c3bfe06bf7d67210fd4dabd286fd2a278ff81267e48fbe71545772b9f3ef6") -- Train Sim World 6 DB BR 187 Loco Add-On - Depot 3662510
setManifestid(3662510, "5467507703423366275", 209035172)
-- Train Sim World 6 Diesel Legends of the Great Western Add-On (AppID: 3662520)
addappid(3662520)
addappid(3662520, 1, "7678690c7f6e4b696162edebe2636de934cafa8ad63a208a2f76b392eb8353c5") -- Train Sim World 6 Diesel Legends of the Great Western Add-On - Depot 3662520
setManifestid(3662520, "7436670855660623357", 445309017)
-- Train Sim World 6 Clinchfield Railroad Elkhorn - Dante Route Add-On (AppID: 3662530)
addappid(3662530)
addappid(3662530, 1, "512c3c6c51f2c4f234fdabefc31e8e97e1aa6ef1de1a9bd31d8e924a69dd7fe8") -- Train Sim World 6 Clinchfield Railroad Elkhorn - Dante Route Add-On - Depot 3662530
setManifestid(3662530, "6208045644272866172", 3783703050)
-- Train Sim World 6 DB BR 101 Loco Add-On (AppID: 3662540)
addappid(3662540)
addappid(3662540, 1, "423cb8e5c37882040a7f280d2755d9f0f941084b7522ac648f9e4561228a0a5e") -- Train Sim World 6 DB BR 101 Loco Add-On - Depot 3662540
setManifestid(3662540, "3219124381588663211", 175277973)
-- Train Sim World 6 Hauptstrecke Hamburg - Lbeck Route Add-On (AppID: 3662550)
addappid(3662550)
addappid(3662550, 1, "97e0160a296ecac40c90bc7df31f0cd658a75cdbcfc10049b05cd54c75f77012") -- Train Sim World 6 Hauptstrecke Hamburg - Lbeck Route Add-On - Depot 3662550
setManifestid(3662550, "658173656244668774", 4605304460)
-- Train Sim World 6 Cathcart Circle Line Glasgow - Neilston  Newton Add-On (AppID: 3662560)
addappid(3662560)
addappid(3662560, 1, "794d0cb850998d2aaac72640274977af0dc2abee2230d2bb7b546496cca8d32d") -- Train Sim World 6 Cathcart Circle Line Glasgow - Neilston  Newton Add-On - Depot 3662560
setManifestid(3662560, "2217126465205864351", 3364791725)
-- Train Sim World 6 London Underground 1938 Stock EMU Loco Add-On (AppID: 3662570)
addappid(3662570)
addappid(3662570, 1, "5c25313103357a5bda47db7785343d78425a6556cbdeab9b75fdc72750e861a8") -- Train Sim World 6 London Underground 1938 Stock EMU Loco Add-On - Depot 3662570
setManifestid(3662570, "6469078600735536501", 246483611)
-- Train Sim World 6 Brighton Main Line London Victoria - Brighton Route Add-On (AppID: 3662630)
addappid(3662630)
addappid(3662630, 1, "cc5f146003dc28eef2662396430d6c9da38635a84d8589301f8dc9494f53f184") -- Train Sim World 6 Brighton Main Line London Victoria - Brighton Route Add-On - Depot 3662630
setManifestid(3662630, "4129989879113851919", 6734752395)
-- Train Sim World 6 Northeast Corridor Boston - Providence Route Add-On (AppID: 3662640)
addappid(3662640)
addappid(3662640, 1, "a82a72e7a0c0e6061f3cd23cc296500e593f9ee7827b1ecb46c093f95bcc91bc") -- Train Sim World 6 Northeast Corridor Boston - Providence Route Add-On - Depot 3662640
setManifestid(3662640, "3860586608755016965", 5379086276)
-- Train Sim World 6 Horseshoe Curve Altoona - Johnstown  South Fork Route Add-On (AppID: 3662650)
addappid(3662650)
addappid(3662650, 1, "02399a1676c2b41bc7ff78aae983891727b1967e24bdad508cdbd974dbcd27b3") -- Train Sim World 6 Horseshoe Curve Altoona - Johnstown  South Fork Route Add-On - Depot 3662650
setManifestid(3662650, "3095378675669810832", 5486424043)
-- Train Sim World 6 West Cornwall Local Penzance - St Austell  St Ives Route Add-On (AppID: 3662660)
addappid(3662660)
addappid(3662660, 1, "fcec919eb0141d993cf59641ca5f01022274ed531e6f2aeb50d7b54de91c4f39") -- Train Sim World 6 West Cornwall Local Penzance - St Austell  St Ives Route Add-On - Depot 3662660
setManifestid(3662660, "5405444324781473348", 3330423275)
-- Train Sim World 6 Sherman Hill Cheyenne - Laramie Route Add-On (AppID: 3662670)
addappid(3662670)
addappid(3662670, 1, "b4f834fc74dbfac8026010692a7eb6ccc6cad3556b60596906ea0f8e236881c4") -- Train Sim World 6 Sherman Hill Cheyenne - Laramie Route Add-On - Depot 3662670
setManifestid(3662670, "3309463526398583276", 5764975343)
-- Train Sim World 6 DB G6 Diesel Shunter Add-On (AppID: 3662690)
addappid(3662690)
addappid(3662690, 1, "c79bdb4aac0829c5b8494ca5eb1a60654a2142352eb208551ea20f87e4a25c00") -- Train Sim World 6 DB G6 Diesel Shunter Add-On - Depot 3662690
setManifestid(3662690, "733574737847075529", 173000234)
-- Train Sim World 6 RhB Anniversary Collection Add-On (AppID: 3662700)
addappid(3662700)
addappid(3662700, 1, "ef43aebbcf3ebf50cf3ff6daec7a61e4061ae2f7690939415307d39f2d6105dd") -- Train Sim World 6 RhB Anniversary Collection Add-On - Depot 3662700
setManifestid(3662700, "9101586198060570906", 280355177)
-- Train Sim World 6 Tharandter Rampe Dresden - Chemnitz Route Add-On (AppID: 3662710)
addappid(3662710)
addappid(3662710, 1, "125dc3a619d3fb1484301d28e15addcc3671b74b3059429440c27bdc76c1c864") -- Train Sim World 6 Tharandter Rampe Dresden - Chemnitz Route Add-On - Depot 3662710
setManifestid(3662710, "1936520867861632927", 7061649056)
-- Train Sim World 6 S-Bahn Zentralschweiz Luzern - Sursee Route Add-On (AppID: 3662720)
addappid(3662720)
addappid(3662720, 1, "418a5c8036243f51ac085f1a600c1f49fd030dcb9de255ba1bc49d895ced0657") -- Train Sim World 6 S-Bahn Zentralschweiz Luzern - Sursee Route Add-On - Depot 3662720
setManifestid(3662720, "3107444200641183461", 4140686553)
-- Train Sim World 6 Harlem Line Grand Central Terminal - North White Plains Route Add-On (AppID: 3662730)
addappid(3662730)
addappid(3662730, 1, "6427428a4c29a516cc8ba31361f46753ff02779f2a02e9e817c0865e80849b69") -- Train Sim World 6 Harlem Line Grand Central Terminal - North White Plains Route Add-On - Depot 3662730
setManifestid(3662730, "5599309408912890454", 5155461212)
-- Train Sim World 6 Schnellfahrstrecke Kassel - Wrzburg Route Add-On (AppID: 3662790)
addappid(3662790)
addappid(3662790, 1, "7a745d387e8f1b30b93b85963418b6bd06518403e3ac12977ff4a6cd783646ed") -- Train Sim World 6 Schnellfahrstrecke Kassel - Wrzburg Route Add-On - Depot 3662790
setManifestid(3662790, "3848406262249125252", 11288420048)
-- Train Sim World 6 Cajon Pass Barstow - San Bernardino Route Add-On (AppID: 3662800)
addappid(3662800)
addappid(3662800, 1, "044cae5f98f9d00ed3e7d5b2eb0d03a01f7065ce34989185d9ece78685ecafb7") -- Train Sim World 6 Cajon Pass Barstow - San Bernardino Route Add-On - Depot 3662800
setManifestid(3662800, "7599594842627827557", 8512281571)
-- Train Sim World 6 Southeastern Highspeed London St Pancras  Ashford Intl  Faversham Route Add-On (AppID: 3662810)
addappid(3662810)
addappid(3662810, 1, "69f2f29346971a8864ec660ba81b8022d8fd71b38b7737d821c5672f89c488be") -- Train Sim World 6 Southeastern Highspeed London St Pancras  Ashford Intl  Faversham Route Add-On - Depot 3662810
setManifestid(3662810, "985962239152101463", 7703653145)
-- Train Sim World 6 Spirit of Steam Liverpool Lime Street - Crewe Route Add-On (AppID: 3662830)
addappid(3662830)
addappid(3662830, 1, "d49efbd8241778b20830c5fe214b6f86d14456a9fc2ad06133dcd9277a1984ee") -- Train Sim World 6 Spirit of Steam Liverpool Lime Street - Crewe Route Add-On - Depot 3662830
setManifestid(3662830, "6444496640861131007", 5376593659)
-- Train Sim World 6 Niddertalbahn Bad Vilbel - Stockheim Route Add-On (AppID: 3662840)
addappid(3662840)
addappid(3662840, 1, "258e37157855c339ea65eaafc1610673fe23b12eaae7ab9d026987a7340449cc") -- Train Sim World 6 Niddertalbahn Bad Vilbel - Stockheim Route Add-On - Depot 3662840
setManifestid(3662840, "6113720097349974407", 9345482376)
-- Train Sim World 6 Schnellfahrstrecke Koln-Aachen Route Add-On (AppID: 3662860)
addappid(3662860)
addappid(3662860, 1, "1778c6e9823e2b6acc42e48931d59a1f0876152b1cd9603a81819083603609ff") -- Train Sim World 6 Schnellfahrstrecke Koln-Aachen Route Add-On - Depot 3662860
setManifestid(3662860, "8807384661767597264", 4172238542)
-- Train Sim World 6 Bakerloo Line Route Add-On (AppID: 3662870)
addappid(3662870)
addappid(3662870, 1, "43ccbfc0d0c26a9aa333e75fc6ba72d018fae304b770f4cec76cc68de7330752") -- Train Sim World 6 Bakerloo Line Route Add-On - Depot 3662870
setManifestid(3662870, "275914024289578342", 4615064290)
-- Train Sim World 6 Sand Patch Grade Route Add-On (AppID: 3662880)
addappid(3662880)
addappid(3662880, 1, "3063a8536100ca5fbd5328e960959bde773a3e190166e7b9020e126ada9e171e") -- Train Sim World 6 Sand Patch Grade Route Add-On - Depot 3662880
setManifestid(3662880, "7211709898307270357", 4092535005)
-- Train Sim World 6 Union Pacific Heritage Livery Collection (AppID: 3662890)
addappid(3662890)
addappid(3662890, 1, "7e54e798cde69702de265738d0dd1fcef008c95bc6fa8db66c1c90cab49f8ee6") -- Train Sim World 6 Union Pacific Heritage Livery Collection - Depot 3662890
setManifestid(3662890, "5956388724975732901", 437262977)
-- Train Sim World 6 Island Line 2022 BR Class 484 EMU Add-On (AppID: 3662900)
addappid(3662900)
addappid(3662900, 1, "d40b8ac286bfabba273c521b2d6a8d25ede91d321a0ab0ee6c126aa01b811e1d") -- Train Sim World 6 Island Line 2022 BR Class 484 EMU Add-On - Depot 3662900
setManifestid(3662900, "1704712585989751606", 2950140978)
-- Train Sim World 6 Rail Head Treatment Train Add-On (AppID: 3662910)
addappid(3662910)
addappid(3662910, 1, "9cf5086c8e629194d3b79dab9be66a52dcee7adc51a1803344475ce4f229e774") -- Train Sim World 6 Rail Head Treatment Train Add-On - Depot 3662910
setManifestid(3662910, "1689111498474240238", 220620779)
-- Train Sim World 6 Santa Fe F7 Add-On (AppID: 3662920)
addappid(3662920)
addappid(3662920, 1, "881d807a95849c54ac3e67c9eb85060c0b50bc688f34377b49c17d4e2cb22d28") -- Train Sim World 6 Santa Fe F7 Add-On - Depot 3662920
setManifestid(3662920, "7294463951350440470", 302060546)
-- Train Sim World 6 Dispolok BR 182 Add-On (AppID: 3662930)
addappid(3662930)
addappid(3662930, 1, "d38041f09d7abcc874db2a55c8f4a2dfec8a6b9a6e54771edfcb58fe4f694dcb") -- Train Sim World 6 Dispolok BR 182 Add-On - Depot 3662930
setManifestid(3662930, "981450996586810516", 159661173)
-- Train Sim World 6 Birmingham Cross-City Line Lichfield - Bromsgrove  Redditch Route Add-On (AppID: 3662940)
addappid(3662940)
addappid(3662940, 1, "4c70deec13fb840e10aa999674ff89d0a4de8a8a2efc7d2877c71a0099d59ed7") -- Train Sim World 6 Birmingham Cross-City Line Lichfield - Bromsgrove  Redditch Route Add-On - Depot 3662940
setManifestid(3662940, "8188536715965890657", 5204616922)
-- Train Sim World 6 Bahnstrecke Bremen - Oldenburg Route Add-On (AppID: 3662950)
addappid(3662950)
addappid(3662950, 1, "8e2261ae8943505df4b217c4c538e83d74f4c47f11f764cb2310bce846cb4a09") -- Train Sim World 6 Bahnstrecke Bremen - Oldenburg Route Add-On - Depot 3662950
setManifestid(3662950, "3330164691315367127", 4958759785)
-- Train Sim World 6 New Journeys - Silver 1972 Stock Add-On (AppID: 3662960)
addappid(3662960)
addappid(3662960, 1, "a6ba58300fd465285567fff87f678f17e8ef9123c254f4d62d7d26adf186f366") -- Train Sim World 6 New Journeys - Silver 1972 Stock Add-On - Depot 3662960
setManifestid(3662960, "1925350281095381899", 165183205)
-- Train Sim World 6 New Journeys - CSX SD40 Add-On (AppID: 3662970)
addappid(3662970)
addappid(3662970, 1, "ecbee0091aa2a49a86d0a91619f84609abd963cbb458b26f006b91514e0a97bc") -- Train Sim World 6 New Journeys - CSX SD40 Add-On - Depot 3662970
setManifestid(3662970, "8547749119638616578", 304853633)
-- Train Sim World 6 New Journeys - S-Bahn Kln BR 423 Add-On (AppID: 3662980)
addappid(3662980)
addappid(3662980, 1, "c8d5935ba03741bd054e79b7a7dcec1d0d5e97b55eabca75972cc5f971ce3f2d") -- Train Sim World 6 New Journeys - S-Bahn Kln BR 423 Add-On - Depot 3662980
setManifestid(3662980, "253987360404757586", 140259848)
-- Train Sim World 6 The Holiday Express - Runaway Elf (AppID: 3662990)
addappid(3662990)
addappid(3662990, 1, "8cae5f0d5f66a7033360d320a81b4e889e64604b631ea631944114d27ddacfbb") -- Train Sim World 6 The Holiday Express - Runaway Elf - Depot 3662990
setManifestid(3662990, "4405248134738160829", 1212296259)
-- Train Sim World 6 ScotRail Express Edinburgh - Glasgow Route Add-On (AppID: 3663000)
addappid(3663000)
addappid(3663000, 1, "bdf140591237f5970b603671805568ad182ee3b9496f690be5301f4f8392cadd") -- Train Sim World 6 ScotRail Express Edinburgh - Glasgow Route Add-On - Depot 3663000
setManifestid(3663000, "2543446545035610524", 5401046514)
-- Train Sim World 6 West Cornwall Steam Railtour Add-On (AppID: 3663010)
addappid(3663010)
addappid(3663010, 1, "d1a69f4c4ab3480bce6ca4e1f05a984e36093eab68bf7a1d64cf3d640dfede3b") -- Train Sim World 6 West Cornwall Steam Railtour Add-On - Depot 3663010
setManifestid(3663010, "881421071336748145", 514082215)
-- Train Sim World 6 Amtraks Acela (AppID: 3663020)
addappid(3663020)
addappid(3663020, 1, "aa2aaad02f0e6e89b744214f0f6a2a026a5334f9b72eaa29b4b4f28a6ac6f477") -- Train Sim World 6 Amtraks Acela - Depot 3663020
setManifestid(3663020, "981338930189006625", 189344232)
-- Train Sim World 6 Thameslink BR Class 7000 EMU Add-On (AppID: 3663030)
addappid(3663030)
addappid(3663030, 1, "d182e917c70626226e0bf935ca6046fcebde91ddf369802c57b7f326f95d945f") -- Train Sim World 6 Thameslink BR Class 7000 EMU Add-On - Depot 3663030
setManifestid(3663030, "300820109245805768", 224156636)
-- Train Sim World 6 Northeast Corridor New York - Trenton (AppID: 3663040)
addappid(3663040)
addappid(3663040, 1, "3fce6dc5fccacc3c7b7ea3492fca078beab859992dd0777c99c2c7fa7b30808b") -- Train Sim World 6 Northeast Corridor New York - Trenton - Depot 3663040
setManifestid(3663040, "8957437418341370272", 6695658791)
-- Train Sim World 6 Peak Forest Railway Ambergate - Chinley  Buxton Route Add-On (AppID: 3663050)
addappid(3663050)
addappid(3663050, 1, "82cc3d4279951f448a62eaec67e36a7384f70a39e2c80d0f440e6946a14a9127") -- Train Sim World 6 Peak Forest Railway Ambergate - Chinley  Buxton Route Add-On - Depot 3663050
setManifestid(3663050, "5561516536149895190", 7090799638)
-- Train Sim World 6 Blackpool Branches Preston - Blackpool  Ormskirk Route Add-On (AppID: 3663060)
addappid(3663060)
addappid(3663060, 1, "6b85a8ad9e15a843e6225d93f3df3cbb09ced7f18e6c2f44a77ca93243e2b1c5") -- Train Sim World 6 Blackpool Branches Preston - Blackpool  Ormskirk Route Add-On - Depot 3663060
setManifestid(3663060, "4458330512250206639", 9350858837)
-- Train Sim World 6 Linke Rheinstrecke Mainz - Koblenz Route Add-On (AppID: 3663070)
addappid(3663070)
addappid(3663070, 1, "4afa73f149b792d87d27f6419144e3b0110cc192465bed74408fe109529b04a0") -- Train Sim World 6 Linke Rheinstrecke Mainz - Koblenz Route Add-On - Depot 3663070
setManifestid(3663070, "67023355566436639", 6160678646)
-- Train Sim World 6 Midland Main Line Leicester - Derby  Nottingham Route Add-On (AppID: 3663090)
addappid(3663090)
addappid(3663090, 1, "75c1b3932711db274429d66447507bd6b2ff17af898b82c139adaea128262be2") -- Train Sim World 6 Midland Main Line Leicester - Derby  Nottingham Route Add-On - Depot 3663090
setManifestid(3663090, "5090446114175221176", 4706576855)
-- Train Sim World 6 BNSF SD70ACe Add-On (AppID: 3663110)
addappid(3663110)
addappid(3663110, 1, "73ebf92bfd55b70554ea42e893a65afd22ea575fe9b836db808880e2797e3a36") -- Train Sim World 6 BNSF SD70ACe Add-On - Depot 3663110
setManifestid(3663110, "806658968731066365", 283117102)
-- Train Sim World 6 Rail Operations Group BR Class 377 Add-On (AppID: 3663130)
addappid(3663130)
addappid(3663130, 1, "2732cb421460f5e5f082be836628898faf91693baa8b542d11c45c9ea227891e") -- Train Sim World 6 Rail Operations Group BR Class 377 Add-On - Depot 3663130
setManifestid(3663130, "2080007833599402284", 264511227)
-- Train Sim World 6 DB BR 403 ICE 3 Railbow Add-On (AppID: 3663150)
addappid(3663150)
addappid(3663150, 1, "943e87fb8bcd454b2b72f1150e885e9ac684eced8c452752637498e5e9f8ffb8") -- Train Sim World 6 DB BR 403 ICE 3 Railbow Add-On - Depot 3663150
setManifestid(3663150, "8209357109251608823", 443332572)
-- Train Sim World 6 Railpool BR 193 Vectron Loco Add-On (AppID: 3663160)
addappid(3663160)
addappid(3663160, 1, "54d3928f6f54b29176b1762ae13c7d78544d86529bc5cb6499e633cb7a43255c") -- Train Sim World 6 Railpool BR 193 Vectron Loco Add-On - Depot 3663160
setManifestid(3663160, "4412751880232253629", 167198772)
-- Train Sim World 6 Glossop Line Manchester - Hadfield  Glossop Route Add-On (AppID: 3663170)
addappid(3663170)
addappid(3663170, 1, "7965b34207bcad4e6bc0b05370a35b8a1b93c844e17c35ef62eaf5032beedea1") -- Train Sim World 6 Glossop Line Manchester - Hadfield  Glossop Route Add-On - Depot 3663170
setManifestid(3663170, "7752341657733763575", 4016648051)
-- Train Sim World 6 LNER Class A3 60103 Flying Scotsman Steam Loco Add-On (AppID: 3663180)
addappid(3663180)
addappid(3663180, 1, "e8a0ba62c05c749128f522d63b1b64f3508dad85a1cb99b465c18c8d25f5c5cc") -- Train Sim World 6 LNER Class A3 60103 Flying Scotsman Steam Loco Add-On - Depot 3663180
setManifestid(3663180, "2284084568237465413", 377189968)
-- Train Sim World 6 Antelope Valley Line Los Angeles - Lancaster Route Add-On (AppID: 3663190)
addappid(3663190)
addappid(3663190, 1, "22f33512fac3f540c343073dbfbfd9cad9149f49d92636f05c93326cc89499f9") -- Train Sim World 6 Antelope Valley Line Los Angeles - Lancaster Route Add-On - Depot 3663190
setManifestid(3663190, "3314228767868045423", 9295528685)
-- Train Sim World 6 East Coast Main Line Peterborough - Doncaster Route Add-On (AppID: 3663200)
addappid(3663200)
addappid(3663200, 1, "18eba7b426dba446c3462b5fa4c69524290497abc9af9b4aa9d657728294e904") -- Train Sim World 6 East Coast Main Line Peterborough - Doncaster Route Add-On - Depot 3663200
setManifestid(3663200, "5588258223310142776", 7887726766)
-- Train Sim World 6 S-Bahn Vorarlberg Lindau - Bludenz Route Add-On (AppID: 3663210)
addappid(3663210)
addappid(3663210, 1, "d855705aa3689fe2ec2b25a058d704cbafe836d6bd797a0290d3c681143e27e5") -- Train Sim World 6 S-Bahn Vorarlberg Lindau - Bludenz Route Add-On - Depot 3663210
setManifestid(3663210, "999845570834106179", 7442299608)
-- Train Sim World 6 Norfolk Southern Heritage Livery Collection Add-On (AppID: 3663220)
addappid(3663220)
addappid(3663220, 1, "4572464f21076886036ea148fb46550d01c06099d859201631d453ab8b0d9ba6") -- Train Sim World 6 Norfolk Southern Heritage Livery Collection Add-On - Depot 3663220
setManifestid(3663220, "8681127076756199222", 311916278)
-- Train Sim World 6 Maintalbahn Aschaffenburg - Miltenberg Route Add-On (AppID: 3663230)
addappid(3663230)
addappid(3663230, 1, "62e4990174ad98fb15fdf842a561113adaf11556b57e25f9c228f51df56e0a6f") -- Train Sim World 6 Maintalbahn Aschaffenburg - Miltenberg Route Add-On - Depot 3663230
setManifestid(3663230, "928196918244802244", 4704283390)
-- Train Sim World 6 RhB Arosa Aggregates Pack (AppID: 3663240)
addappid(3663240)
addappid(3663240, 1, "c3000d5f4e71f83ba0df05c4e4244dd2849cb831fdcbaae809d65e797d37e608") -- Train Sim World 6 RhB Arosa Aggregates Pack - Depot 3663240
setManifestid(3663240, "5015862463191341854", 224097507)
-- Train Sim World 6 Cargo Line Vol. 1 - Petroleum (AppID: 3663250)
addappid(3663250)
addappid(3663250, 1, "dfbc28c019c615344009c9274c820628b794142cfcbc3fbd2839aadd3bd20dc4") -- Train Sim World 6 Cargo Line Vol. 1 - Petroleum - Depot 3663250
setManifestid(3663250, "6490808273875516318", 343778304)
-- Train Sim World 6 Centro Regional Railways BR Class 323 Add-On (AppID: 3663260)
addappid(3663260)
addappid(3663260, 1, "cff854b7d26039ce93c2cf0e8cb7f013e08a4ecbba4f3cd6417157ab4339e509") -- Train Sim World 6 Centro Regional Railways BR Class 323 Add-On - Depot 3663260
setManifestid(3663260, "7466501002149036066", 197722659)
-- Train Sim World 6 Edinburgh - Glasgow Engineering Express Pack (AppID: 3663270)
addappid(3663270)
addappid(3663270, 1, "bd5de7a202ae992165fb062bfe8dbb898230a5b12e4bf0ffb7974a4a17a2b2c0") -- Train Sim World 6 Edinburgh - Glasgow Engineering Express Pack - Depot 3663270
setManifestid(3663270, "3143896959903038573", 342972563)
-- Train Sim World 6 Berninalinie Tirano - Ospizio Bernina Route Add-On (AppID: 3663280)
addappid(3663280)
addappid(3663280, 1, "8db28d66babfa84341b2bf5941c225f9f4073cc0f5a9492a69e9b644af0c8f0f") -- Train Sim World 6 Berninalinie Tirano - Ospizio Bernina Route Add-On - Depot 3663280
setManifestid(3663280, "525924770112487701", 5036197350)
-- Train Sim World 6 LIRR Commuter New York - Long Beach, Hempstead  Hicksville Route Add-On (AppID: 3663300)
addappid(3663300)
addappid(3663300, 1, "0df8d4e8348dcdc2e77776821f9f3aa6ff29aaab7c908b44b05f59958e00951e") -- Train Sim World 6 LIRR Commuter New York - Long Beach, Hempstead  Hicksville Route Add-On - Depot 3663300
setManifestid(3663300, "6304269102247347328", 8515527620)
-- Train Sim World 6 Bahnstrecke Salzburg - Rosenheim Route Add-On (AppID: 3663310)
addappid(3663310)
addappid(3663310, 1, "f599850f43f662de0aea722b3b91321bb0e0d78e9c9376925bef96abd10d23cb") -- Train Sim World 6 Bahnstrecke Salzburg - Rosenheim Route Add-On - Depot 3663310
setManifestid(3663310, "8091443450474853221", 6808125024)
-- Train Sim World 6 London Overground Suffragette line Gospel Oak - Barking Riverside Route Add-On (AppID: 3663320)
addappid(3663320)
addappid(3663320, 1, "9ade913c0bc958a7fecb72604be656d2ffc68087122d3424268b0849f622193f") -- Train Sim World 6 London Overground Suffragette line Gospel Oak - Barking Riverside Route Add-On - Depot 3663320
setManifestid(3663320, "2704676021315109562", 5555072655)
-- Train Sim World 6 Cargo Line Vol. 2 - Aggregates (AppID: 3663330)
addappid(3663330)
addappid(3663330, 1, "9d64942fa70e2a33087de2fe915c572679216cfe92dc9b47a56cbe4d87295b4a") -- Train Sim World 6 Cargo Line Vol. 2 - Aggregates - Depot 3663330
setManifestid(3663330, "8014269335052916673", 219362923)
-- Train Sim World 6 Fife Circle Line  Levenmouth Rail Link Route Add-On (AppID: 3663340)
addappid(3663340)
addappid(3663340, 1, "b112c0fd1432969c9498955651e1fb8bfe97d0f4a70d89acc3e4adeab3824d5e") -- Train Sim World 6 Fife Circle Line  Levenmouth Rail Link Route Add-On - Depot 3663340
setManifestid(3663340, "1454338680691141428", 7621264553)
-- Train Sim World 6 ScotRail BR Class 158 Sprinter DMU Add-On (AppID: 3663350)
addappid(3663350)
addappid(3663350, 1, "8b16aaeb213c8bca3d8a84f43006e5d60a517d60634d06abfcb7e3218f07fe96") -- Train Sim World 6 ScotRail BR Class 158 Sprinter DMU Add-On - Depot 3663350
setManifestid(3663350, "3000887646545958252", 212150341)
-- Train Sim World 6 ECML Diesel Railtour Pack (AppID: 3663380)
addappid(3663380)
addappid(3663380, 1, "ca4feadae7214631891d464a9777a901d02853ba5451681f256b432ba2cbc9fa") -- Train Sim World 6 ECML Diesel Railtour Pack - Depot 3663380
setManifestid(3663380, "8446351882571738200", 496711496)
-- Train Sim World 6 Semmeringbahn Wiener Neustadt - Mrzzuschlag Route Add-On (AppID: 3663390)
addappid(3663390)
addappid(3663390, 1, "991f41f07d5a7a0480a9a7b850d3bdfb68a586d59009abd37bd9f555fd32f79e") -- Train Sim World 6 Semmeringbahn Wiener Neustadt - Mrzzuschlag Route Add-On - Depot 3663390
setManifestid(3663390, "32010687369849004", 6864768189)
-- Train Sim World 6 West Coast Main Line Preston - Carlisle Route Add-On (AppID: 3663400)
addappid(3663400)
addappid(3663400, 1, "60a6b680b137362c72d1418467f4c662eb50e3bfda223d441b21d7bff0171e31") -- Train Sim World 6 West Coast Main Line Preston - Carlisle Route Add-On - Depot 3663400
setManifestid(3663400, "9112675307000644841", 18271850253)
-- Train Sim World 6 DB BR 218 Diesel Loco Add-On (AppID: 3663410)
addappid(3663410)
addappid(3663410, 1, "053f4799993b5e019f8feb14e0f9c55a9a05ee7997ca12ec15361080601145b4") -- Train Sim World 6 DB BR 218 Diesel Loco Add-On - Depot 3663410
setManifestid(3663410, "6481410992802757297", 315414029)
-- Train Sim World 6 Expert DB BR 101  IC Steuerwagen Loco Add-On (AppID: 3663420)
addappid(3663420)
addappid(3663420, 1, "69e993af21e6097f2b80760f9b98abebed763ff1b8e395827b3390572046ed1f") -- Train Sim World 6 Expert DB BR 101  IC Steuerwagen Loco Add-On - Depot 3663420
setManifestid(3663420, "4445005485864094664", 447460639)
-- Train Sim World 6 ScotRail BR Class 380 EMU Add-On (AppID: 3663430)
addappid(3663430)
addappid(3663430, 1, "c3a0c5806cb4f8dc81b86d069e33b5e978ee391b18da2103a2bb1972fcd70d64") -- Train Sim World 6 ScotRail BR Class 380 EMU Add-On - Depot 3663430
setManifestid(3663430, "1181608559209386218", 250466293)
-- Train Sim World 6 San Bernardino Line Los Angeles - San Bernardino Route Add-On (AppID: 3663440)
addappid(3663440)
addappid(3663440, 1, "3f7a2ab91af51632041f011256fcebbe08de30f7b1a27c91e70285f5f8efb5d1") -- Train Sim World 6 San Bernardino Line Los Angeles - San Bernardino Route Add-On - Depot 3663440
setManifestid(3663440, "6685787567004510548", 9445343658)
-- Train Sim World 6 West Coast Main Line London Euston - Milton Keynes Route Add-On (AppID: 3663450)
addappid(3663450)
addappid(3663450, 1, "07d81bd1203efb37ffdce6b179765479ba3470c212a7415ef7c23e620b90d331") -- Train Sim World 6 West Coast Main Line London Euston - Milton Keynes Route Add-On - Depot 3663450
setManifestid(3663450, "8366429165685780266", 8686870429)
-- Train Sim World 6 Frankfurt - Fulda Kinzigtalbahn Route Add-On (AppID: 3663460)
addappid(3663460)
addappid(3663460, 1, "2d0143c54b62210792e6a4468013bdef2b577ce60ffaaaecda84a0f928ca5034") -- Train Sim World 6 Frankfurt - Fulda Kinzigtalbahn Route Add-On - Depot 3663460
setManifestid(3663460, "2687791374636289394", 10489876914)
-- Train Sim World 6 Avanti West Coast BR Class 390 Pendolino EMU Add-On (AppID: 3663470)
addappid(3663470)
addappid(3663470, 1, "6a85752b5da0f74f8386fe2c9275224fdf7f3d4444b4733e040a06da05fe5835") -- Train Sim World 6 Avanti West Coast BR Class 390 Pendolino EMU Add-On - Depot 3663470
setManifestid(3663470, "8475955234406651802", 366757451)
-- Train Sim World 6 FlixTrain BR 193 Vectron Loco Add-On (AppID: 3663480)
addappid(3663480)
addappid(3663480, 1, "5c139e532c5eaaeef8754bb01afb0018e955e2368355e778f012812c5eb72e0d") -- Train Sim World 6 FlixTrain BR 193 Vectron Loco Add-On - Depot 3663480
setManifestid(3663480, "2242740540097572548", 317704370)
-- Train Sim World 6 Mittenwaldbahn Innsbruck - Garmisch-Partenkirchen Route Add-On (AppID: 3663490)
addappid(3663490)
addappid(3663490, 1, "2463b8ff44b43a548c5c3f570b3d03892b8e21661f3705b221db7f5c72157493") -- Train Sim World 6 Mittenwaldbahn Innsbruck - Garmisch-Partenkirchen Route Add-On - Depot 3663490
setManifestid(3663490, "273553957561723666", 12651599150)
-- Train Sim World 6 MBTA Commuter Boston - FraminghamWorcester Line Route Add-On (AppID: 3663500)
addappid(3663500)
addappid(3663500, 1, "d69b4b60c31e6ad7758ff4600a1ffe366c48a1a51b0327554e2f74b3eae82499") -- Train Sim World 6 MBTA Commuter Boston - FraminghamWorcester Line Route Add-On - Depot 3663500
setManifestid(3663500, "4690149596949992761", 8621585473)
-- Train Sim World 6 Pflzische Ludwigsbahn Mannheim - Kaiserslautern Route Add-On (AppID: 3663510)
addappid(3663510)
addappid(3663510, 1, "4edb5d1f81f47c016c7b152f1dc2e19189ed16d469bd58bb6aa7d32db165eb1c") -- Train Sim World 6 Pflzische Ludwigsbahn Mannheim - Kaiserslautern Route Add-On - Depot 3663510
setManifestid(3663510, "3985462418946728371", 7318356642)
-- Train Sim World 6 London Overground Mildmay line Stratford - Willesden Junction Route Add-On (AppID: 3663520)
addappid(3663520)
addappid(3663520, 1, "f81c863cb9e71416d7b857d8ab01c66c2afce593e400b02aa4431127c6a79ecc") -- Train Sim World 6 London Overground Mildmay line Stratford - Willesden Junction Route Add-On - Depot 3663520
setManifestid(3663520, "159945704429784041", 5949555083)
-- Train Sim World 6 Cargo Line Vol. 3 - Intermodal (AppID: 3663530)
addappid(3663530)
addappid(3663530, 1, "8f5d620d57f11f34326a75d137e0208c0161f5a78d68287b09aea5fc91bb4931") -- Train Sim World 6 Cargo Line Vol. 3 - Intermodal - Depot 3663530
setManifestid(3663530, "3605350180860428900", 228531212)
-- Train Sim World 6 Cardiff City Network Radur  Coryton  Penarth  Bae Caerdydd Route Add-On (AppID: 3663540)
addappid(3663540)
addappid(3663540, 1, "04942d1dcab769d2f440cb20fa6f26be71ddfc4ac3786b0357abf5d082543b19") -- Train Sim World 6 Cardiff City Network Radur  Coryton  Penarth  Bae Caerdydd Route Add-On - Depot 3663540
setManifestid(3663540, "2356100928564168215", 3346505753)
-- Train Sim World 6 Thomas  Friends Visit the West Somerset Railway (AppID: 3663560)
addappid(3663560)
addappid(3663560, 1, "5c5bfe629b85077a52bc6db8eaf5e21f6230318de2d1ad26b011bda4df29421d") -- Train Sim World 6 Thomas  Friends Visit the West Somerset Railway - Depot 3663560
setManifestid(3663560, "6728430545246229767", 683154676)
-- Train Sim World 6 Metrolink Holiday Train Pack (AppID: 3663570)
addappid(3663570)
addappid(3663570, 1, "667c30ade662b814981d6b4e9ffa81302aa12d3e0f18dfde25749dbf9435e7a8") -- Train Sim World 6 Metrolink Holiday Train Pack - Depot 3663570
setManifestid(3663570, "3312077073035954657", 115508656)
-- Train Sim World 6 HKA Bogie Hopper Wagon Pack (AppID: 3663580)
addappid(3663580)
addappid(3663580, 1, "77215e209d6fc6236d8e013a43b7d084f5ac9ee68d4425eb00ae2022db65c371") -- Train Sim World 6 HKA Bogie Hopper Wagon Pack - Depot 3663580
setManifestid(3663580, "3852623702965891369", 36963253)
-- Train Sim World 6 DB BR 111  n-Wagen Pack (AppID: 3663600)
addappid(3663600)
addappid(3663600, 1, "4bf08764f14c6a0e02e6fefcc50303559264f4f624bde505b9694d1d276385c6") -- Train Sim World 6 DB BR 111  n-Wagen Pack - Depot 3663600
setManifestid(3663600, "4048695477348325341", 255905591)
-- Train Sim World 6 Spoorlijn Zwolle - Groningen Route Add-On (AppID: 3663610)
addappid(3663610)
addappid(3663610, 1, "0e1a5eb2c5c1fc29eead1c4e0aed4c2572ddcedb19c5334cb67cb97a604fbd16") -- Train Sim World 6 Spoorlijn Zwolle - Groningen Route Add-On - Depot 3663610
setManifestid(3663610, "3918607018579004981", 7091511540)
-- Train Sim World 6 Metrolink F59PHR Loco Add-On (AppID: 3663620)
addappid(3663620)
addappid(3663620, 1, "0b5e40c727091f60948b667d6fefa37d9944a930f69d7d022a204f5f9d0edaec") -- Train Sim World 6 Metrolink F59PHR Loco Add-On - Depot 3663620
setManifestid(3663620, "5140741782169498478", 251111858)
-- Train Sim World 6 Frankfurt S-Bahn S1, S8  S9 Route Add-On (AppID: 3663640)
addappid(3663640)
addappid(3663640, 1, "8eacc45e6767ff709d6c2e3339880bc90060c6b0a92fc13de12e8b0975b8b724") -- Train Sim World 6 Frankfurt S-Bahn S1, S8  S9 Route Add-On - Depot 3663640
setManifestid(3663640, "6320243268525077962", 8697768887)
-- Train Sim World 6 Thomas  Friends 80th Anniversary Expansion (AppID: 3663650)
addappid(3663650)
addappid(3663650, 1, "bf0d1db5113a1cfbf0b1a2ef11609fd726eedd68d444aec2b06491f003c97d8d") -- Train Sim World 6 Thomas  Friends 80th Anniversary Expansion - Depot 3663650
setManifestid(3663650, "8716081902642480696", 107571716)
-- Train Sim World 6 Cargo Line Vol. 4 - Military (AppID: 3663810)
addappid(3663810)
addappid(3663810, 1, "97cf28735000f5ba917560d757409815fb13f5c3561b0abeab848bf29cd7bbef") -- Train Sim World 6 Cargo Line Vol. 4 - Military - Depot 3663810
setManifestid(3663810, "6045404680818192945", 302932636)
-- Train Sim World 6 BR Class 862  Mk2F Coaches Loco Add-On (AppID: 3663820)
addappid(3663820)
addappid(3663820, 1, "9f417cd0351392bef29af5041b8849f3589262961f6eef5f4519c6acfbd8cfea") -- Train Sim World 6 BR Class 862  Mk2F Coaches Loco Add-On - Depot 3663820
setManifestid(3663820, "1923469329459231751", 1532522138)
-- Train Sim World 6 BR 194  E94 Railtour Pack (AppID: 3663830)
addappid(3663830)
addappid(3663830, 1, "6b4083cffb07cdb6dee5ae5393b6ff74ed7b8d946b9e49a242f1929ed4e9203c") -- Train Sim World 6 BR 194  E94 Railtour Pack - Depot 3663830
setManifestid(3663830, "7959409476258679843", 769973402)
-- Train Sim World 6 Manchester Airport Commuter Manchester - Alderley Edge Route Add-On (AppID: 3663840)
addappid(3663840)
addappid(3663840, 1, "95d307cb5ce3517c4b1acb33f122b4d43588160ddb195336750f95e38ce1af79") -- Train Sim World 6 Manchester Airport Commuter Manchester - Alderley Edge Route Add-On - Depot 3663840
setManifestid(3663840, "2140704577383822989", 11137513766)
-- Train Sim World 6 MBTA ProvidenceStoughton Line HSP46 Add-On (AppID: 3663860)
addappid(3663860)
addappid(3663860, 1, "b59b513ad948aa2030f8296af15a7f67b52aaabeaff990dd458519eb10c21a3b") -- Train Sim World 6 MBTA ProvidenceStoughton Line HSP46 Add-On - Depot 3663860
setManifestid(3663860, "3983275435753699836", 432876477)
-- Train Sim World 6 Expert DB BR 101 on Kassel - Wrzburg Gameplay Pack (AppID: 3663870)
addappid(3663870)
addappid(3663870, 1, "92fdc7e9193fe094e0968665ec2e718b5ec83a5405e68731d7cf525fe0be432f") -- Train Sim World 6 Expert DB BR 101 on Kassel - Wrzburg Gameplay Pack - Depot 3663870
setManifestid(3663870, "3909658673532340245", 56514488)
-- Train Sim World 6 West Midlands Railway  CrossCountry BR Class 170 DMU Add-On (AppID: 3663880)
addappid(3663880)
addappid(3663880, 1, "855206ef408b32d3c81a45de2b6a8f8107c81b5401a574302401cbd18c488cfe") -- Train Sim World 6 West Midlands Railway  CrossCountry BR Class 170 DMU Add-On - Depot 3663880
setManifestid(3663880, "4315892482876923525", 310943124)