-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 3167540 Manifest
-- Name: Not Monday Cafe
-- Generated: 2025-06-26 07:03:48
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3167540) -- Not Monday Cafe

-- MAIN APP DEPOTS
addappid(3167541, 1, "d4aaad748f8899ae323b910dd54e0f6ccf51ec6706dbd4fdb8e4bf827e0f2aea") -- Depot 3167541
setManifestid(3167541, "6630669650669420726", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3787780) -- Not Monday Cafe - Supporter Pack
