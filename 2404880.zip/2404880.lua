-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2404880 Manifest
-- Name: Car Dealer Simulator
-- Generated: 2025-06-27 11:21:05
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2404880) -- Car Dealer Simulator

-- MAIN APP DEPOTS
addappid(2404881, 1, "dd3322cbddd81741e4bd8f3d9d08fbe6ff172e3f5c36fec42e215f6661d3ea4f") -- Depot 2404881
setManifestid(2404881, "926981093506056616", 0)
