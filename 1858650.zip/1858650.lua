-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1858650 Manifest
-- Name: In Sink
-- Generated: 2025-06-28 22:41:57
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1858650) -- In Sink

-- MAIN APP DEPOTS
addappid(1858652, 1, "7559977939e30619429f880437084991c4f807e755c509ca88987b500426198d") -- Depot 1858652
setManifestid(1858652, "4627989735447518019", 0)

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- In Sink Soundtrack (AppID: 3313890) - missing depot keys
-- addappid(3313890)
