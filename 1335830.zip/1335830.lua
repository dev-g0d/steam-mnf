-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1335830 Manifest
-- Name: Len's Island
-- Generated: 2025-06-25 09:13:56
-- Total Depots: 2
-- Total DLCs: 2 (1 excluded)

-- MAIN APPLICATION
addappid(1335830) -- Len's Island

-- MAIN APP DEPOTS
addappid(1335831, 1, "f2232a3bfcb5c7612c95312dfd25d89e6f0795121c0554e12b911b6f8d982e65") -- Len's Island Content
setManifestid(1335831, "4401574341108232455", 0)
addappid(1335832, 1, "3415b4a91f32415894d413bde36a9241af420679c00e1b11fb96c0c8ad90dcbd") -- Len's Island Mac Content
setManifestid(1335832, "974776363876166765", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3795980) -- Lens Island - Gothic Building Style
addappid(3809990) -- Lens Island - Supporter Pack

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Lens Island Soundtrack (AppID: 1787330) - missing depot keys
-- addappid(1787330)
