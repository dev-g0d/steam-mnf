-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1796470 Manifest
-- Name: Haste
-- Generated: 2025-06-26 07:37:28
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1796470) -- Haste

-- MAIN APP DEPOTS
addappid(1796471, 1, "1be44ffc3d55a3bfef475a9ca61508d531a7ff622c0d1ae83629e6b393fa0932") -- Depot 1796471
setManifestid(1796471, "3890005690302658844", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Haste Soundtrack (AppID: 3587100)
addappid(3587100)
addappid(3587102, 1, "3480d60cd7ed2b25daa568920bcea90ab3b655070f8d80eae64afd9a66abb8a0") -- Haste Soundtrack - Depot 3587102
setManifestid(3587102, "2925846499593192497", 0)
addappid(3587101, 1, "2c0b7404519eef3fad96505eee8ef9dfd335c1c26ede4ca40ffa3ab7d0f0617e") -- Haste Soundtrack - Depot 3587101
setManifestid(3587101, "5671927963192264899", 0)
