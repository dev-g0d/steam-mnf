-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1593500 Manifest
-- Name: God of War
-- Generated: 2025-06-05 19:31:48
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1593500) -- God of War

-- MAIN APP DEPOTS
addappid(1593501, 1, "77f7390a115063bccc41240f71e0bf27d42c6a7c0424657756fe3f99f26a287a") -- God of War Content
setManifestid(1593501, "2535153423663269664", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
