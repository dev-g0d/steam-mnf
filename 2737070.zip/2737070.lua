-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2737070 Manifest
-- Name: Crime Simulator
-- Generated: 2025-06-26 11:05:28
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2737070) -- Crime Simulator

-- MAIN APP DEPOTS
addappid(2737071, 1, "36e272c2274c8d6dbf4a697d1faa618de36bbacf8439215d60cca4350601aedb") -- Depot 2737071
setManifestid(2737071, "166340571599119805", 0)
