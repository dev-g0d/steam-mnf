-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1659040 Manifest
-- Name: HITMAN World of Assassination
-- Generated: 2025-06-12 04:53:52
-- Total Depots: 1
-- Total DLCs: 30

-- MAIN APPLICATION
addappid(1659040) -- HITMAN World of Assassination

-- MAIN APP DEPOTS
addappid(1659041, 1, "891bd9670c03fa74065659fe448680b55b5279707dfe40493d5f00372e02b42f") -- HITMAN 3 Content
setManifestid(1659041, "6711704740148543453", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1829580) -- HITMAN 3 - Seven Deadly Sins Act 1 Greed
addappid(1829581) -- HITMAN 3 - Seven Deadly Sins Act 2 Pride
addappid(1829582) -- HITMAN 3 - Seven Deadly Sins Act 3 Sloth
addappid(1829583) -- HITMAN 3 - Seven Deadly Sins Act 4 Lust
addappid(1829584) -- HITMAN 3 - Seven Deadly Sins Act 5 Gluttony
addappid(1829585) -- HITMAN 3 - Seven Deadly Sins Act 6 Envy
addappid(1829586) -- HITMAN 3 - Seven Deadly Sins Act 7 Wrath
addappid(1829587) -- HITMAN 3 - Seven Deadly Sins Collection
addappid(1829590) -- HITMAN 3 Access Pass HITMAN 2 Expansion
addappid(1829591) -- HITMAN 3 - Deluxe Pack
addappid(1829592) -- HITMAN 3 Access Pass HITMAN 2 Standard
addappid(1829593) -- HITMAN 3 Access Pass HITMAN 1 Complete First Season
addappid(1829594) -- HITMAN 3 - VR Access
addappid(1829595) -- HITMAN 3 Access Pass HITMAN 1 GOTY Upgrade
addappid(1829596) -- HITMAN 3 - Trinity Pack
addappid(1829600) -- HITMAN 3 - Carpathian Mountains
addappid(1829601) -- HITMAN 3 - Mendoza
addappid(1829602) -- HITMAN 3 - Chongqing
addappid(1829603) -- HITMAN 3 - Berlin
addappid(1829604) -- HITMAN 3 - Dartmoor
addappid(1829605) -- HITMAN 3 - Dubai
addappid(1843460) -- HITMAN 3 Access Pass HITMAN 1 GOTY Edition
addappid(2184790) -- HITMAN 3 - Street Art Pack
addappid(2184791) -- HITMAN 3 - Makeshift Pack
addappid(2475260) -- HITMAN 3 - Sarajevo Six Campaign Pack
addappid(2828470) -- HITMAN 3 - The Undying Pack
addappid(2973650) -- HITMAN 3 - The Disruptor Pack
addappid(3110360) -- HITMAN 3 - The Drop Pack
addappid(3254350) -- HITMAN 3 - The Splitter Pack
addappid(3711140) -- HITMAN 3 - The Banker Pack
